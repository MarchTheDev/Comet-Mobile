import { useMemo, useState } from "react";
import {
  Archive,
  ArrowLeft,
  BookOpen,
  CalendarDays,
  Check,
  ChevronRight,
  CircleEllipsis,
  Clock3,
  File,
  FileText,
  Folder,
  FolderKanban,
  Grid2X2,
  House,
  KeyRound,
  Link,
  ListChecks,
  Menu,
  Mic,
  MoreHorizontal,
  Network,
  Newspaper,
  Paperclip,
  PenLine,
  Pin,
  Plus,
  Radio,
  Search,
  Settings2,
  ShieldCheck,
  Sparkles,
  Star,
  Tag,
  X,
  type LucideIcon,
} from "lucide-react";

type View = "Today" | "Library" | "Calendar" | "Feed" | "More";

type NavItem = {
  label: string;
  icon: LucideIcon;
  color?: string;
  count?: number;
};

const navItems: NavItem[] = [
  { label: "All files", icon: BookOpen, color: "#617f91", count: 24 },
  { label: "Pinned", icon: Pin, color: "#d78a4d", count: 3 },
  { label: "Favorites", icon: Star, color: "#b48a45", count: 6 },
  { label: "Tree view", icon: Network, color: "#6b8ca0" },
  { label: "Brain view", icon: Sparkles, color: "#7775a8" },
];

const toolItems: NavItem[] = [
  { label: "Boards", icon: FolderKanban, color: "#6e8e7b" },
  { label: "Calendar", icon: CalendarDays, color: "#ba6e65" },
  { label: "RSS reader", icon: Radio, color: "#bd7b50", count: 8 },
  { label: "Passwords", icon: KeyRound, color: "#6d73a0" },
  { label: "Offline tools", icon: Grid2X2, color: "#778f9d" },
];

const recentFiles = [
  {
    title: "Product launch notes",
    meta: "Projects · Edited 12m ago",
    icon: FileText,
    tone: "blue",
  },
  { title: "Reading list", meta: "Personal · Edited yesterday", icon: ListChecks, tone: "green" },
  { title: "Design resources", meta: "Resources · Edited Friday", icon: Link, tone: "purple" },
];

const calendarEntries = [
  { time: "10:00", title: "Weekly product sync", color: "#7b9aaa" },
  { time: "14:30", title: "Review launch notes", color: "#b9826d" },
  { time: "17:00", title: "Reading time", color: "#7f927c" },
];

function App() {
  const [view, setView] = useState<View>("Today");
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [captureOpen, setCaptureOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [completed, setCompleted] = useState(false);
  const [toast, setToast] = useState("");

  const title = selectedFile ?? view;

  const searchResults = useMemo(
    () => [
      { title: "Product launch notes", path: "Projects / Launch" },
      { title: "Launch checklist", path: "Boards / Product" },
      { title: "Welcome to Comet", path: "Getting started" },
    ],
    [],
  );

  const selectView = (next: View) => {
    setView(next);
    setSelectedFile(null);
    setDrawerOpen(false);
  };

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  };

  return (
    <main className="stage">
      <section className="ios-app" aria-label="Comet mobile app">
        <div className="status-bar" aria-hidden="true">
          <span>9:41</span>
          <div className="dynamic-island" />
          <div className="status-icons">
            <i className="signal" />
            <i className="wifi" />
            <i className="battery" />
          </div>
        </div>

        <header className="mobile-header">
          {selectedFile ? (
            <button
              className="round-button"
              onClick={() => setSelectedFile(null)}
              aria-label="Back"
            >
              <ArrowLeft size={20} />
            </button>
          ) : (
            <button
              className="round-button brand-button"
              onClick={() => setDrawerOpen(true)}
              aria-label="Open sidebar"
            >
              <Menu size={19} />
            </button>
          )}
          <div className="header-title">
            <span>{selectedFile ? "PROJECTS" : view === "Today" ? "YOUR SPACE" : "COMET"}</span>
            <h1>{title}</h1>
          </div>
          <button className="round-button" onClick={() => setSearchOpen(true)} aria-label="Search">
            <Search size={19} />
          </button>
        </header>

        <div className="content-scroll">
          {selectedFile ? (
            <NoteView completed={completed} setCompleted={setCompleted} />
          ) : view === "Today" ? (
            <TodayView
              completed={completed}
              setCompleted={setCompleted}
              openFile={setSelectedFile}
              showToast={showToast}
            />
          ) : view === "Library" ? (
            <LibraryView openFile={setSelectedFile} />
          ) : view === "Calendar" ? (
            <CalendarView />
          ) : view === "Feed" ? (
            <FeedView />
          ) : (
            <MoreView onOpenSidebar={() => setDrawerOpen(true)} />
          )}
        </div>

        {!selectedFile && (
          <>
            <nav className="tab-bar" aria-label="Main navigation">
              <TabButton
                active={view === "Today"}
                icon={House}
                label="Today"
                onClick={() => selectView("Today")}
              />
              <TabButton
                active={view === "Library"}
                icon={Folder}
                label="Library"
                onClick={() => selectView("Library")}
              />
              <button
                className="capture-tab"
                onClick={() => setCaptureOpen(true)}
                aria-label="Create new item"
              >
                <Plus size={25} strokeWidth={2.4} />
              </button>
              <TabButton
                active={view === "Calendar"}
                icon={CalendarDays}
                label="Calendar"
                onClick={() => selectView("Calendar")}
              />
              <TabButton
                active={view === "More" || view === "Feed"}
                icon={CircleEllipsis}
                label="More"
                onClick={() => selectView("More")}
              />
            </nav>
            <div className="home-indicator" />
          </>
        )}

        {drawerOpen && (
          <div className="overlay" onMouseDown={() => setDrawerOpen(false)}>
            <aside className="drawer" onMouseDown={(event) => event.stopPropagation()}>
              <div className="drawer-handle" />
              <div className="drawer-brand">
                <img src="/comet-mark.svg" alt="" />
                <div>
                  <strong>
                    comet<span>.</span>
                  </strong>
                  <small>Your space, on this device</small>
                </div>
                <button onClick={() => setDrawerOpen(false)} aria-label="Close sidebar">
                  <X size={19} />
                </button>
              </div>
              <button className="workspace-card">
                <span className="workspace-letter">M</span>
                <span>
                  <strong>My workspace</strong>
                  <small>On my iPhone · 24 files</small>
                </span>
                <ChevronRight size={17} />
              </button>
              <button
                className="drawer-search"
                onClick={() => {
                  setDrawerOpen(false);
                  setSearchOpen(true);
                }}
              >
                <Search size={17} />
                <span>Search anything</span>
                <small>⌘ K</small>
              </button>
              <div className="drawer-scroll">
                <p className="drawer-label">Explore</p>
                {navItems.map((item) => (
                  <DrawerItem
                    key={item.label}
                    item={item}
                    onClick={() => {
                      setView("Library");
                      setDrawerOpen(false);
                    }}
                  />
                ))}
                <p className="drawer-label">Workspace</p>
                {toolItems.map((item) => (
                  <DrawerItem
                    key={item.label}
                    item={item}
                    onClick={() => {
                      if (item.label === "Calendar") setView("Calendar");
                      else if (item.label === "RSS reader") setView("Feed");
                      else setView("More");
                      setDrawerOpen(false);
                    }}
                  />
                ))}
                <div className="folder-section">
                  <div>
                    <span>Your files</span>
                    <Plus size={15} />
                  </div>
                  <button>
                    <Folder size={16} /> Projects <span>8</span>
                  </button>
                  <button>
                    <Folder size={16} /> Personal <span>7</span>
                  </button>
                  <button>
                    <Folder size={16} /> Resources <span>9</span>
                  </button>
                </div>
              </div>
              <div className="privacy-row">
                <ShieldCheck size={18} />
                <span>
                  <strong>Local-first</strong>
                  <small>Your files stay on this device.</small>
                </span>
                <Settings2 size={18} />
              </div>
            </aside>
          </div>
        )}

        {captureOpen && (
          <div className="overlay sheet-overlay" onMouseDown={() => setCaptureOpen(false)}>
            <div className="capture-sheet" onMouseDown={(event) => event.stopPropagation()}>
              <div className="sheet-handle" />
              <div className="sheet-heading">
                <div>
                  <span>QUICK CAPTURE</span>
                  <h2>Add something new</h2>
                </div>
                <button onClick={() => setCaptureOpen(false)}>
                  <X size={18} />
                </button>
              </div>
              <div className="capture-grid">
                <CaptureButton
                  icon={PenLine}
                  label="New note"
                  tone="blue"
                  onClick={() => {
                    setCaptureOpen(false);
                    setSelectedFile("Untitled note");
                  }}
                />
                <CaptureButton
                  icon={ListChecks}
                  label="Task"
                  tone="green"
                  onClick={() => {
                    setCaptureOpen(false);
                    showToast("Task added to Today");
                  }}
                />
                <CaptureButton
                  icon={Mic}
                  label="Audio"
                  tone="orange"
                  onClick={() => showToast("Recording ready")}
                />
                <CaptureButton
                  icon={Paperclip}
                  label="Import file"
                  tone="purple"
                  onClick={() => showToast("Choose a file to import")}
                />
              </div>
              <button className="scan-action" onClick={() => showToast("Document scanner opened")}>
                <Archive size={19} />
                <span>
                  <strong>Scan a document</strong>
                  <small>Save as a searchable PDF</small>
                </span>
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        )}

        {searchOpen && (
          <div className="search-screen">
            <div className="search-status-space" />
            <div className="search-top">
              <div className="search-field">
                <Search size={18} />
                <input autoFocus placeholder="Search notes, files, and tags" />
                <Mic size={17} />
              </div>
              <button onClick={() => setSearchOpen(false)}>Cancel</button>
            </div>
            <p className="search-label">Suggested</p>
            {searchResults.map((result) => (
              <button
                className="search-result"
                key={result.title}
                onClick={() => {
                  setSelectedFile(result.title);
                  setSearchOpen(false);
                }}
              >
                <span>
                  <FileText size={18} />
                </span>
                <div>
                  <strong>{result.title}</strong>
                  <small>{result.path}</small>
                </div>
                <ChevronRight size={17} />
              </button>
            ))}
            <div className="search-tip">
              <Sparkles size={17} />
              <span>Search inside documents, PDFs, and saved articles.</span>
            </div>
          </div>
        )}

        {toast && (
          <div className="toast">
            <Check size={16} />
            {toast}
          </div>
        )}
      </section>
    </main>
  );
}

function TodayView({
  completed,
  setCompleted,
  openFile,
  showToast,
}: {
  completed: boolean;
  setCompleted: (value: boolean) => void;
  openFile: (name: string) => void;
  showToast: (message: string) => void;
}) {
  return (
    <div className="page today-page">
      <section className="welcome-card">
        <div className="orbit orbit-one" />
        <div className="orbit orbit-two" />
        <div className="welcome-mark">
          <Sparkles size={17} />
        </div>
        <span>MONDAY, JUNE 24</span>
        <h2>
          A quiet place
          <br />
          for what matters.
        </h2>
        <p>Everything in your orbit, ready when you are.</p>
      </section>

      <section className="section-block">
        <div className="section-title">
          <div>
            <span>UP NEXT</span>
            <h3>Today</h3>
          </div>
          <button onClick={() => showToast("Calendar opened")}>View day</button>
        </div>
        <div className="task-card">
          <button
            className={`task-check ${completed ? "checked" : ""}`}
            onClick={() => setCompleted(!completed)}
          >
            {completed && <Check size={14} />}
          </button>
          <div>
            <strong className={completed ? "done" : ""}>Review launch checklist</strong>
            <span>
              <Clock3 size={13} /> 2:30 PM · Product
            </span>
          </div>
          <button>
            <MoreHorizontal size={19} />
          </button>
        </div>
      </section>

      <section className="section-block">
        <div className="section-title">
          <div>
            <span>PICK UP WHERE YOU LEFT OFF</span>
            <h3>Recent</h3>
          </div>
          <button onClick={() => openFile("Product launch notes")}>See all</button>
        </div>
        <div className="recent-list">
          {recentFiles.map((file) => {
            const Icon = file.icon;
            return (
              <button key={file.title} className="recent-row" onClick={() => openFile(file.title)}>
                <span className={`file-icon ${file.tone}`}>
                  <Icon size={20} />
                </span>
                <span>
                  <strong>{file.title}</strong>
                  <small>{file.meta}</small>
                </span>
                <ChevronRight size={18} />
              </button>
            );
          })}
        </div>
      </section>

      <section className="insight-card">
        <div className="insight-icon">
          <Network size={21} />
        </div>
        <div>
          <span>FROM YOUR BRAIN</span>
          <strong>3 notes connect to “Launch”</strong>
          <small>Explore related ideas in Brain view</small>
        </div>
        <ChevronRight size={18} />
      </section>
    </div>
  );
}

function NoteView({
  completed,
  setCompleted,
}: {
  completed: boolean;
  setCompleted: (value: boolean) => void;
}) {
  return (
    <article className="note-page">
      <div className="note-meta">
        <span>PROJECTS</span>
        <button>
          <CircleEllipsis size={21} />
        </button>
      </div>
      <h2>Product launch notes</h2>
      <div className="note-chips">
        <span>
          <Clock3 size={13} /> Edited 12m ago
        </span>
        <span>
          <Tag size={13} /> Launch
        </span>
      </div>
      <p>
        Everything we need to bring the next release across the finish line—clearly, calmly, and
        together.
      </p>
      <h3>Monday priorities</h3>
      <button className="note-task" onClick={() => setCompleted(!completed)}>
        <span className={completed ? "checked" : ""}>{completed && <Check size={13} />}</span>
        <strong className={completed ? "done" : ""}>Review final launch checklist</strong>
      </button>
      <button className="note-task">
        <span />
        <strong>Confirm App Store screenshots</strong>
      </button>
      <button className="note-task">
        <span />
        <strong>Schedule launch announcement</strong>
      </button>
      <blockquote>Keep the release focused. We can always make the next version better.</blockquote>
      <h3>Notes</h3>
      <p>
        The new onboarding flow is approved. Marketing copy should keep the same quiet, human tone
        used throughout the product.
      </p>
      <div className="editor-toolbar">
        <button>
          <strong>B</strong>
        </button>
        <button>
          <em>I</em>
        </button>
        <button>H1</button>
        <button>
          <ListChecks size={18} />
        </button>
        <button>
          <Link size={18} />
        </button>
        <button>
          <Plus size={18} />
        </button>
      </div>
    </article>
  );
}

function LibraryView({ openFile }: { openFile: (name: string) => void }) {
  return (
    <div className="page">
      <div className="library-summary">
        <div>
          <span>24</span>
          <small>Files</small>
        </div>
        <div>
          <span>3</span>
          <small>Folders</small>
        </div>
        <div>
          <span>8</span>
          <small>Tags</small>
        </div>
      </div>
      <div className="section-title">
        <div>
          <span>YOUR FILES</span>
          <h3>Library</h3>
        </div>
        <button>
          <Grid2X2 size={17} />
        </button>
      </div>
      <div className="folder-grid">
        {["Projects", "Personal", "Resources"].map((folder, index) => (
          <button key={folder}>
            <Folder size={24} />
            <strong>{folder}</strong>
            <small>{[8, 7, 9][index]} items</small>
          </button>
        ))}
      </div>
      <div className="section-title file-heading">
        <div>
          <span>RECENTLY UPDATED</span>
          <h3>Files</h3>
        </div>
        <button>Sort</button>
      </div>
      <div className="recent-list">
        {recentFiles
          .concat([
            {
              title: "Welcome to Comet",
              meta: "Getting started · Jun 18",
              icon: File,
              tone: "orange",
            },
          ])
          .map((file) => {
            const Icon = file.icon;
            return (
              <button className="recent-row" key={file.title} onClick={() => openFile(file.title)}>
                <span className={`file-icon ${file.tone}`}>
                  <Icon size={20} />
                </span>
                <span>
                  <strong>{file.title}</strong>
                  <small>{file.meta}</small>
                </span>
                <MoreHorizontal size={18} />
              </button>
            );
          })}
      </div>
    </div>
  );
}

function CalendarView() {
  return (
    <div className="page">
      <div className="calendar-card">
        <div className="calendar-head">
          <button>‹</button>
          <strong>June 2025</strong>
          <button>›</button>
        </div>
        <div className="week-row">
          {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => (
            <span key={`${day}-${index}`}>{day}</span>
          ))}
        </div>
        <div className="date-row">
          {[23, 24, 25, 26, 27, 28, 29].map((date) => (
            <button key={date} className={date === 24 ? "active" : ""}>
              {date}
            </button>
          ))}
        </div>
      </div>
      <div className="section-title calendar-title">
        <div>
          <span>MONDAY, JUNE 24</span>
          <h3>3 events</h3>
        </div>
        <button>
          <Plus size={17} />
        </button>
      </div>
      <div className="agenda">
        {calendarEntries.map((entry) => (
          <div key={entry.time}>
            <time>{entry.time}</time>
            <i style={{ background: entry.color }} />
            <span>
              <strong>{entry.title}</strong>
              <small>My workspace</small>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

function FeedView() {
  return (
    <div className="page">
      <div className="feed-hero">
        <Newspaper size={25} />
        <span>8 UNREAD</span>
        <h2>
          Your quiet corner
          <br />
          of the internet.
        </h2>
        <p>Saved feeds, no algorithm.</p>
      </div>
      {[
        "Design Details — The beauty of quiet software",
        "Dense Discovery — Issue 334",
        "Local-first software: you own your data",
      ].map((title, index) => (
        <button className="article-row" key={title}>
          <i className={`article-dot ${index ? "" : "unread"}`} />
          <span>
            <strong>{title}</strong>
            <small>
              {index === 0
                ? "Design Details · 12 min"
                : index === 1
                  ? "Dense Discovery · 1h"
                  : "Ink & Switch · Yesterday"}
            </small>
          </span>
          <ChevronRight size={17} />
        </button>
      ))}
    </div>
  );
}

function MoreView({ onOpenSidebar }: { onOpenSidebar: () => void }) {
  return (
    <div className="page more-page">
      <button className="profile-card" onClick={onOpenSidebar}>
        <img src="/comet-mark.svg" alt="" />
        <span>
          <strong>My workspace</strong>
          <small>Local on this iPhone</small>
        </span>
        <ChevronRight size={18} />
      </button>
      <p className="group-label">TOOLS & SPACES</p>
      <div className="settings-group">
        {toolItems.map((item) => {
          const Icon = item.icon;
          return (
            <button key={item.label}>
              <i style={{ background: `${item.color}18`, color: item.color }}>
                <Icon size={18} />
              </i>
              <span>{item.label}</span>
              {item.count && <small>{item.count}</small>}
              <ChevronRight size={17} />
            </button>
          );
        })}
      </div>
      <p className="group-label">COMET</p>
      <div className="settings-group">
        <button>
          <i>
            <Tag size={18} />
          </i>
          <span>Manage tags</span>
          <ChevronRight size={17} />
        </button>
        <button>
          <i>
            <Settings2 size={18} />
          </i>
          <span>Settings</span>
          <ChevronRight size={17} />
        </button>
      </div>
      <div className="local-card">
        <ShieldCheck size={20} />
        <span>
          <strong>Private by default</strong>
          <small>No account. No database. Your files stay yours.</small>
        </span>
      </div>
    </div>
  );
}

function TabButton({
  active,
  icon: Icon,
  label,
  onClick,
}: {
  active: boolean;
  icon: LucideIcon;
  label: string;
  onClick: () => void;
}) {
  return (
    <button className={active ? "active" : ""} onClick={onClick}>
      <Icon size={21} />
      <span>{label}</span>
    </button>
  );
}

function DrawerItem({ item, onClick }: { item: NavItem; onClick: () => void }) {
  const Icon = item.icon;
  return (
    <button className="drawer-item" onClick={onClick}>
      <i style={{ color: item.color }}>
        <Icon size={18} />
      </i>
      <span>{item.label}</span>
      {item.count !== undefined && <small>{item.count}</small>}
      <ChevronRight size={16} />
    </button>
  );
}

function CaptureButton({
  icon: Icon,
  label,
  tone,
  onClick,
}: {
  icon: LucideIcon;
  label: string;
  tone: string;
  onClick: () => void;
}) {
  return (
    <button className={`capture-option ${tone}`} onClick={onClick}>
      <span>
        <Icon size={22} />
      </span>
      <strong>{label}</strong>
    </button>
  );
}

export default App;
